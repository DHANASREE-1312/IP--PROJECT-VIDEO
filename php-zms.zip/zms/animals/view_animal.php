<?php
if(isset($_GET['id']) && $_GET['id'] > 0){
    $qry = $conn->query("SELECT * from `animal_list` where id = '{$_GET['id']}' ");
    if($qry->num_rows > 0){
        foreach($qry->fetch_assoc() as $k => $v){
            $$k=$v;
        }
    }
}
?>
<style>
    #animal-logo{
        max-width:100%;
        max-height: 20em;
        object-fit:scale-down;
        object-position:center center;
    }
</style>
<div class="container">
    <div class="content py-5 px-3 bg-gradient-olive">
        <h2><b>Animal Details</b></h2>
    </div>
    <div class="row mt-lg-n4 mt-md-n4 justify-content-center">
        <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
            <div class="card rounded-0">
                <div class="card-header py-1">
                    <div class="card-tools">
                        <a class="btn btn-light btn-sm bg-gradient-light border rounded-0" href="./?p=animals"><i class="fa fa-angle-left"></i> Back to List</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="container-fluid">
                        <center>
                            <img src="<?= validate_image(isset($image_path) ? $image_path : '') ?>" alt="" class="img-thumbnail border border-dark bg-gradient-dark rounded-0 p-0" id="animal-logo">
                        </center>
                        <dl>
                            <dt class="text-muted">Cage No.</dt>
                            <dd class="pl-4"><?= isset($cage_no) ? $cage_no : "" ?></dd>
                            <dt class="text-muted">Name</dt>
                            <dd class="pl-4"><?= isset($name) ? $name : "" ?></dd>
                            <dt class="text-muted">Description</dt>
                            <dd class="pl-4"><?= isset($description) ? htmlspecialchars_decode($description) : '' ?></dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
